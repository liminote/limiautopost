## Lovable 設計交付說明（limiautopost）

目標：請優化 UI/版面（Notion 風格、緊湊）、並改善互動細節。產出可直接回貼取代既有檔案的程式碼，不新增相依。

### 風格與設計原則
- 採用 Notion-like、緊湊設計，表格字體 12px、白色 tooltip、陰影、扁平 tags、hover 顯示關閉、輸入高度 28px、平台選單 Threads/IG 顯示清楚（沿用 tokens）
- 全域 tokens 已定義，請沿用 `src/index.css`（不要引入 UI 套件或自訂設計系統）
- 保持簡潔、對齊、易讀，不要讓浮層造成重排抖動

設計偏好與 tokens 來源：見 `src/index.css`，以及下方貼入的片段；此為產品既有規範，請勿修改語意。

### 技術限制
- 僅用 Tailwind utility classes 與現有 `src/index.css` 中的全域樣式
- 不新增第三方相依
- 保留 TypeScript 型別與資料流，允許調整 JSX 結構與 className
- 任何互動效果需無 layout shift（不影響表格與整體寬高）

### 需要你設計/優化的區塊
1) TrackingPage（追蹤列表）
   - 搜尋列與表格的視覺（緊湊、清楚）、表頭固定風格可加強
   - 內容（截斷）欄位的「全文浮窗」：
     - 使用 position: fixed，顯示在該格的側邊（優先右側，不夠空間則左側），垂直位置夾取在視窗內
     - 白底/陰影/圓角（沿用 `.ui-tooltip`）
     - 微延遲隱藏（避免滑鼠移至浮窗時消失），不能造成版面抖動
   - Tag 輸入的建議清單沿用 `.ui-tooltip` 視覺

2) Generator（結果卡片）
   - 卡片標題、平台、小按鈕配置調整，使其更緊湊易讀
   - 複製、加入追蹤等操作區的一致性與對齊

### 驗收標準（重要）
- 表格與卡片的縱橫間距符合緊湊風格（表格 12px 行高、單元格內邊距小）
- 全文浮窗：穩定出現於單元格側邊，無重排、無抖動，滑鼠移到浮窗不會立即消失
- 不新增任何套件，相容現有程式與建置

### 交付項目
- 回傳可直接替換的檔案：`src/pages/app/Tracking.tsx`、`src/pages/app/Generator.tsx`（如需抽成 `components/` 也可，但請附帶檔案）
- 如需新增少量樣式，請改在 `src/index.css` 並沿用 tokens

---

### 參考：全域樣式 tokens（節錄自 `src/index.css`）

```css
/* Notion-like UI (compact) */
:root{
  --ui-bg:#fff; --ui-fg:#111827; --ui-border:#e5e7eb; --ui-chip:#f3f4f6;
  --ui-shadow:0 6px 16px rgba(0,0,0,.12);
}
html{ overflow-y: scroll; }
body{ min-height:100%; scrollbar-gutter: stable; }
.ui-12{font-size:12px;}
.table.ui-compact thead th{padding:6px 8px;}
.table.ui-compact tbody td{padding:6px 8px;}
.ui-input-sm,.ui-select-sm{height:28px;padding:3px 8px;font-size:12px;border:1px solid var(--ui-border);border-radius:6px;background:var(--ui-bg);}
.ui-chip{display:inline-flex;align-items:center;gap:4px;padding:2px 6px;border:0;border-radius:6px;background:var(--ui-chip);font-size:11px;line-height:18px;}
.ui-chip .ui-close{opacity:0;transition:opacity .15s}
.ui-chip:hover .ui-close{opacity:.8}
.ui-tooltip{background:var(--ui-bg);border:1px solid var(--ui-border);box-shadow:var(--ui-shadow);border-radius:8px;}
```

---

### 目前 Tracking.tsx（供你參考與直接改寫）

```tsx
// file: src/pages/app/Tracking.tsx
import { useEffect, useRef, useState, useLayoutEffect } from 'react'
import { getTracked, removeTracked, clearTracked, updateTracked, type TrackedPost } from '../../tracking/tracking'

export default function TrackingPage() {
  const [rows, setRows] = useState<TrackedPost[]>([])
  const [hoverId, setHoverId] = useState<string | null>(null)
  const [hoverPos, setHoverPos] = useState<{ left: number; top: number } | null>(null)
  const [hoverText, setHoverText] = useState<string>('')
  const hideTimerRef = useRef<number | null>(null)
  const anchorRectRef = useRef<DOMRect | null>(null)
  const tooltipRef = useRef<HTMLDivElement | null>(null)

  const clearHideTimer = () => {
    if (hideTimerRef.current) {
      window.clearTimeout(hideTimerRef.current)
      hideTimerRef.current = null
    }
  }
  const hideTooltipLater = () => {
    clearHideTimer()
    hideTimerRef.current = window.setTimeout(() => {
      setHoverId(null)
      setHoverPos(null)
      setHoverText('')
    }, 120)
  }

  useLayoutEffect(() => {
    if (!hoverId || !anchorRectRef.current) return
    const margin = 8
    const viewportW = window.innerWidth
    const viewportH = window.innerHeight

    const fallbackLeft = Math.max(margin, Math.min(anchorRectRef.current.left, viewportW - margin - 1))
    const fallbackTop = Math.max(margin, Math.min(anchorRectRef.current.bottom + margin, viewportH - margin - 1))
    let left = fallbackLeft
    let top = fallbackTop

    const el = tooltipRef.current
    if (el) {
      const w = el.offsetWidth
      const h = el.offsetHeight
      const canPlaceRight = anchorRectRef.current.right + margin + w <= viewportW - margin
      const canPlaceLeft = anchorRectRef.current.left - margin - w >= margin
      if (canPlaceRight) {
        left = anchorRectRef.current.right + margin
      } else if (canPlaceLeft) {
        left = anchorRectRef.current.left - margin - w
      } else {
        left = Math.max(margin, Math.min(anchorRectRef.current.left, viewportW - margin - w))
      }
      const desiredTop = anchorRectRef.current.top
      top = Math.max(margin, Math.min(desiredTop, viewportH - margin - h))
    }
    setHoverPos({ left, top })
  }, [hoverId, hoverText])

  const refresh = () => setRows(getTracked())
  useEffect(() => { refresh() }, [])

  const exportCSV = () => { /* 省略，與原檔相同 */ }

  return (
    <div className="space-y-4 ui-12">
      {/* ...搜尋列與表格。重點在「內容（截斷）」欄位：*/}
      <td className="px-3 py-2 border-t text-gray-600 align-top">
        <div
          className="max-w-64"
          onMouseEnter={(e) => {
            clearHideTimer()
            const rect = (e.currentTarget as HTMLDivElement).getBoundingClientRect()
            anchorRectRef.current = rect
            setHoverText('此處放全文內容')
            setHoverId('hover-row-id')
          }}
          onMouseLeave={hideTooltipLater}
        >
          <span>內容開頭…</span>
        </div>
      </td>

      {hoverId && hoverPos && (
        <div
          ref={tooltipRef}
          className="fixed z-50 w-[24rem] max-h-56 overflow-auto p-2 ui-tooltip ui-12 whitespace-pre-wrap"
          style={{ left: hoverPos.left, top: hoverPos.top }}
          onMouseEnter={clearHideTimer}
          onMouseLeave={hideTooltipLater}
        >
          {hoverText}
        </div>
      )}
    </div>
  )
}
```

---

### 目前 Generator.tsx（供你參考與直接改寫）

```tsx
// file: src/pages/app/Generator.tsx
/* 保持資料流不變，可自由調整卡片視覺（卡片間距、標題、平台、操作列等） */
export default function Generator(){ /* 省略，與原檔相同，可直接在 className 上優化 */ return null as any }
```

---

### 目前 index.css（供你參考與直接改寫）

```css
/* file: src/index.css（請沿用 tokens，必要時在此新增極少量樣式） */
/* Notion-like UI (compact) */
:root{ --ui-bg:#fff; --ui-fg:#111827; --ui-border:#e5e7eb; --ui-chip:#f3f4f6; --ui-shadow:0 6px 16px rgba(0,0,0,.12); }
html{ overflow-y: scroll; }
body{ min-height:100%; scrollbar-gutter: stable; }
.ui-12{font-size:12px;}
.table.ui-compact thead th{padding:6px 8px;}
.table.ui-compact tbody td{padding:6px 8px;}
.ui-input-sm,.ui-select-sm{height:28px;padding:3px 8px;font-size:12px;border:1px solid var(--ui-border);border-radius:6px;background:var(--ui-bg);}
.ui-chip{display:inline-flex;align-items:center;gap:4px;padding:2px 6px;border:0;border-radius:6px;background:var(--ui-chip);font-size:11px;line-height:18px;}
.ui-chip .ui-close{opacity:0;transition:opacity .15s}
.ui-chip:hover .ui-close{opacity:.8}
.ui-tooltip{background:var(--ui-bg);border:1px solid var(--ui-border);box-shadow:var(--ui-shadow);border-radius:8px;}
```

---

### 執行方式（本地）
- 開發：`npm run dev`（Vite，127.0.0.1:4182）
- 建置：`npm run build`


