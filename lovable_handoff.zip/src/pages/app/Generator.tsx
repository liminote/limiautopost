import { useEffect, useMemo, useState } from 'react'
import { addTracked, getTracked, removeTracked, clearTracked, nextArticleId } from '../../tracking/tracking'
import type { TrackedPost } from '../../tracking/tracking'

type Platform = 'Threads' | 'Instagram' | 'Facebook'

type Card = {
  id: string
  platform: Platform
  label: string
  content: string
  checked: boolean
  code: string // T1/T2/T3/IG/MAN
}

export default function Generator() {
  const [title, setTitle] = useState('')
  const [article, setArticle] = useState('')
  const [generating, setGenerating] = useState(false)
  const [cards, setCards] = useState<Card[]>([])
  const [tracked, setTracked] = useState<TrackedPost[]>([])

  const refreshTracked = () => setTracked(getTracked())
  useEffect(() => { refreshTracked() }, [])

  const anyChecked = useMemo(() => cards.some(c => c.checked), [cards])

  const onGenerate = () => {
    setGenerating(true)
    setTimeout(() => {
      const res = generateFrom(article)
      const articleId = nextArticleId()
      const newCards: Card[] = [
        { id: crypto.randomUUID(), platform: 'Threads', label: `Threads 建議 1（約 500 字） · ${articleId}`, content: res[0], checked: false, code: 'T1' },
        { id: crypto.randomUUID(), platform: 'Threads', label: `Threads 建議 2（約 350 字） · ${articleId}`, content: res[1], checked: false, code: 'T2' },
        { id: crypto.randomUUID(), platform: 'Threads', label: `Threads 建議 3（約 200 字） · ${articleId}`, content: res[2], checked: false, code: 'T3' },
        { id: crypto.randomUUID(), platform: 'Instagram', label: `Instagram 建議 · ${articleId}`, content: res[3], checked: false, code: 'IG' },
      ]
      setCards(newCards)
      setGenerating(false)
    }, 300)
  }

  const onCopy = async (content: string) => {
    try { await navigator.clipboard.writeText(content); alert('已複製到剪貼簿') } catch { alert('複製失敗') }
  }

  const addManual = () => {
    setCards(prev => ([
      ...prev,
      { id: crypto.randomUUID(), platform: 'Threads', label: '手動新增', content: '', checked: false, code: 'MAN' }
    ]))
  }

  const onAddToTracking = () => {
    const selected = cards.filter(c => c.checked)
    if (!selected.length) return
    // 從第一張卡片的 label 取出 Axxx（若沒有，臨時給一個）
    const articleId = /A\d{3}/.exec(selected[0]?.label || '')?.[0] || nextArticleId()
    addTracked(selected.map(c => ({
      articleId,
      branchCode: c.code,
      postId: '',
      articleTitle: title,
      content: c.content,
      platform: c.platform,
    })))
    alert('已加入追蹤列表：' + selected.length + ' 筆')
    setCards(prev => prev.map(c => ({ ...c, checked: false })))
    refreshTracked()
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* 左：輸入與設定 */}
      <div className="lg:col-span-1 space-y-4">
        <div className="card card-body space-y-3">
          <div>
            <label className="block text-sm text-gray-600">標題</label>
            <input className="mt-1 input" value={title} onChange={e=>setTitle(e.target.value)} placeholder="輸入原文標題" />
          </div>
          <div>
            <label className="block text-sm text-gray-600">文章</label>
            <textarea className="mt-1 textarea h-56" value={article} onChange={e=>setArticle(e.target.value)} placeholder="貼上完整長文…" />
          </div>
          <div className="flex gap-2">
            <button className="btn btn-ghost text-gray-500 cursor-not-allowed" title="即將推出" disabled>個人化風格設定</button>
            <button className="ml-auto btn btn-primary disabled:opacity-50" disabled={!article || generating} onClick={onGenerate}>
              {generating ? '生成中…' : '開始生成貼文'}
            </button>
          </div>
        </div>
      </div>

      {/* 中：結果卡片 */}
      <div className="lg:col-span-2 space-y-4">
        {cards.length === 0 ? (
          <div className="text-sm text-gray-500">尚未有結果，請先輸入文章並點「開始生成貼文」。</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {cards.map((c) => (
              <div key={c.id} className="relative card card-body flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <div className="font-medium">{c.label} · {c.platform}</div>
                  <label className="inline-flex items-center gap-2 text-sm">
                    <input type="checkbox" className="size-4" checked={c.checked} onChange={e=> setCards(prev => prev.map(x => x.id===c.id? { ...x, checked: e.target.checked }: x))} />
                    選取
                  </label>
                </div>
                {c.code === 'MAN' && (
                  <select className="select w-40 text-sm" value={c.platform} onChange={e=> setCards(prev => prev.map(x => x.id===c.id? { ...x, platform: e.target.value as Platform }: x))}>
                    <option>Threads</option>
                    <option>Instagram</option>
                    <option>Facebook</option>
                  </select>
                )}
                <textarea className="textarea text-sm" value={c.content} onChange={e=> setCards(prev => prev.map(x => x.id===c.id? { ...x, content: e.target.value }: x))} />
                <div className="flex justify-end">
                  <button className="btn btn-outline text-sm" onClick={()=>onCopy(c.content)}>複製</button>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="flex items-center gap-3">
          <button className="btn btn-outline" onClick={addManual}>＋ 手動新增卡片</button>
          {anyChecked && (
            <button className="ml-auto btn btn-primary" onClick={onAddToTracking}>將選取項目加入追蹤列表</button>
          )}
        </div>
      </div>

      {/* 右：追蹤列表 */}
      <div className="lg:col-span-1 space-y-4">
        <div className="card">
          <div className="card-header flex items-center justify-between">
            <span>追蹤列表</span>
            <div className="flex items-center gap-2">
              <button className="btn btn-ghost text-xs" onClick={refreshTracked}>重新整理</button>
              <button
                className="btn btn-outline text-xs"
                onClick={() => {
                  if (!tracked.length) return
                  const header = ['postId','articleId','articleTitle','platform','branchCode','content','permalink','publishDate','likes','comments','shares','saves','notes','createdAt']
                  const rows = tracked.map(t => [
                    t.postId,
                    t.articleId,
                    (t.articleTitle || '').replaceAll('\n',' '),
                    t.platform,
                    t.branchCode,
                    (t.content || '').replaceAll('\n',' '),
                    t.permalink ?? '',
                    t.publishDate ?? '',
                    t.likes ?? 0,
                    t.comments ?? 0,
                    t.shares ?? 0,
                    t.saves ?? 0,
                    t.notes ?? '',
                    t.createdAt ?? '',
                  ])
                  const lines = [header, ...rows]
                    .map(r => r.map(x => '"' + String(x ?? '').replaceAll('"','""') + '"').join(','))
                    .join('\r\n')
                  const csv = '\\uFEFF' + lines
                  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
                  const url = URL.createObjectURL(blob)
                  const a = document.createElement('a')
                  a.href = url
                  a.download = 'tracked-posts.csv'
                  a.click()
                  URL.revokeObjectURL(url)
                }}
              >匯出CSV</button>
              <button className="btn btn-ghost text-xs" onClick={() => { if (confirm('清空所有追蹤項目？')) { clearTracked(); refreshTracked() } }}>清空</button>
            </div>
          </div>
          <div className="card-body space-y-3">
            {tracked.length === 0 ? (
              <div className="text-sm text-gray-500">尚無追蹤項目</div>
            ) : (
              <ul className="space-y-3">
                {tracked.map(item => (
                  <li key={item.id} className="border rounded p-3 bg-white/60">
                    <div className="text-sm text-gray-500">{item.platform} · {item.branchCode}</div>
                    <div className="font-medium">{item.articleTitle || '（無標題）'}</div>
                    <div className="mt-1 line-clamp-2 text-sm text-gray-600">{item.content}</div>
                    <div className="mt-2 flex justify-end gap-2">
                      <button className="btn btn-outline text-xs" onClick={() => onCopy(item.content)}>複製內容</button>
                      <button className="btn btn-ghost text-xs" onClick={() => { removeTracked(item.id); refreshTracked() }}>移除</button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

function generateFrom(text: string): [string, string, string, string] {
  const cleaned = text.replace(/\n+/g, '\n').trim()
  const parts = cleaned.split(/(?<=[。！？!?.])\s*/)
  const makeLen = (limit: number) => {
    if (!cleaned) return ''
    let out = ''
    for (const s of parts) {
      if ((out + s).length > limit) break
      out += s
    }
    if (!out) out = cleaned.slice(0, limit)
    return out
  }
  return [makeLen(500), makeLen(350), makeLen(200), makeLen(220)]
}


