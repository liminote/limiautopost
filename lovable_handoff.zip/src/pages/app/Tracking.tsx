import { useEffect, useRef, useState, useLayoutEffect } from 'react'
import { getTracked, removeTracked, clearTracked, updateTracked, type TrackedPost } from '../../tracking/tracking'

export default function TrackingPage() {
  const [rows, setRows] = useState<TrackedPost[]>([])
  const [hoverId, setHoverId] = useState<string | null>(null)
  const [hoverPos, setHoverPos] = useState<{ left: number; top: number } | null>(null)
  const [hoverText, setHoverText] = useState<string>('')
  const hideTimerRef = useRef<number | null>(null)
  const anchorRectRef = useRef<DOMRect | null>(null)
  const tooltipRef = useRef<HTMLDivElement | null>(null)

  const clearHideTimer = () => {
    if (hideTimerRef.current) {
      window.clearTimeout(hideTimerRef.current)
      hideTimerRef.current = null
    }
  }
  const hideTooltipLater = () => {
    clearHideTimer()
    hideTimerRef.current = window.setTimeout(() => {
      setHoverId(null)
      setHoverPos(null)
      setHoverText('')
    }, 120)
  }

  useLayoutEffect(() => {
    if (!hoverId || !anchorRectRef.current) return
    const margin = 8
    const viewportW = window.innerWidth
    const viewportH = window.innerHeight

    // 若還未渲染出來，先給一個初始位置避免閃爍
    const fallbackLeft = Math.max(margin, Math.min(anchorRectRef.current.left, viewportW - margin - 1))
    const fallbackTop = Math.max(margin, Math.min(anchorRectRef.current.bottom + margin, viewportH - margin - 1))
    let left = fallbackLeft
    let top = fallbackTop

    const el = tooltipRef.current
    if (el) {
      const w = el.offsetWidth
      const h = el.offsetHeight
      const canPlaceRight = anchorRectRef.current.right + margin + w <= viewportW - margin
      const canPlaceLeft = anchorRectRef.current.left - margin - w >= margin
      if (canPlaceRight) {
        left = anchorRectRef.current.right + margin
      } else if (canPlaceLeft) {
        left = anchorRectRef.current.left - margin - w
      } else {
        left = Math.max(margin, Math.min(anchorRectRef.current.left, viewportW - margin - w))
      }
      const desiredTop = anchorRectRef.current.top
      top = Math.max(margin, Math.min(desiredTop, viewportH - margin - h))
    }
    setHoverPos({ left, top })
  }, [hoverId, hoverText])
  const refresh = () => setRows(getTracked())
  useEffect(() => { refresh() }, [])

  const exportCSV = () => {
    if (!rows.length) return
    const header = ['postId','articleId','articleTitle','platform','content','permalink','publishDate','likes','comments','shares','saves','notes','createdAt']
    const data = rows.map(r => [
      r.postId,
      r.articleId,
      (r.articleTitle||'').replaceAll('\n',' '),
      r.platform,
      (r.content||'').replaceAll('\n',' '),
      r.permalink ?? '',
      r.publishDate ?? '',
      r.likes ?? 0,
      r.comments ?? 0,
      r.shares ?? 0,
      r.saves ?? 0,
      r.notes ?? '',
      r.createdAt ?? '',
    ])
    const lines = [header, ...data]
      .map(r => r.map(x => '"' + String(x ?? '').replaceAll('"','""') + '"').join(','))
      .join('\r\n')
    const csv = '\uFEFF' + lines
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'tracked-posts.csv'
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-4 ui-12">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold" style={{ fontFamily: 'Noto Serif TC, serif' }}>追蹤列表</h1>
        <div className="flex items-center gap-2">
          <button className="btn btn-outline text-sm" onClick={exportCSV}>匯出 CSV</button>
          <button className="btn btn-ghost text-sm" onClick={refresh}>重新整理</button>
          <button className="btn btn-ghost text-sm" onClick={() => { if (confirm('清空所有追蹤項目？')) { clearTracked(); refresh() } }}>清空</button>
        </div>
      </div>

      <SearchBar onFilter={(keyword, start, end) => {
        const all = getTracked()
        const kw = keyword.trim()
        const filtered = all.filter(r => {
          const inKw = kw ? (
            r.postId.includes(kw) || r.articleId.includes(kw) ||
            (r.articleTitle||'').includes(kw) || (r.content||'').includes(kw) ||
            (r.tags||[]).some(t => t.includes(kw))
          ) : true
          const ct = r.createdAt ? new Date(r.createdAt).getTime() : 0
          const inStart = start ? ct >= new Date(start).getTime() : true
          const inEnd = end ? ct <= new Date(end).getTime() + 24*60*60*1000 - 1 : true
          return inKw && inStart && inEnd
        })
        setRows(filtered)
      }} />

      <div className="overflow-x-auto card">
        <table className="table ui-compact">
          <thead>
            <tr>
              <th>貼文識別碼</th>
              <th>原文編號</th>
              <th>原文標題</th>
              <th>平台</th>
              <th>內容（截斷）</th>
              <th>標籤</th>
              <th>貼文連結</th>
              <th>發佈日期</th>
              <th>讚</th>
              <th>留言</th>
              <th>分享</th>
              <th>儲存</th>
              <th>備註</th>
              <th>建立時間</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr><td colSpan={15} className="px-3 py-6 text-center text-gray-500">尚無資料</td></tr>
            ) : rows.map(r => (
              <tr key={r.id}>
                <td className="px-3 py-2 border-t">{r.postId}</td>
                <td className="px-3 py-2 border-t">{r.articleId}</td>
                <td className="px-3 py-2 border-t">{r.articleTitle || '（無標題）'}</td>

                <td className="px-3 py-2 border-t">
                  <select
                    className="ui-select-sm"
                    value={(r.platform ?? (r.articleId?.toUpperCase().includes('IG') ? 'Instagram' : 'Threads')) as TrackedPost['platform']}
                    onChange={(e)=>{ const v = e.target.value as TrackedPost['platform']; updateTracked(r.id, { platform: v }); setRows(prev => prev.map(x=> x.id===r.id? { ...x, platform: v }: x)); }}
                  >
                    <option value="Threads">Threads</option>
                    <option value="Instagram">Instagram</option>
                    <option value="Facebook">Facebook</option>
                  </select>
                </td>

                <td className="px-3 py-2 border-t text-gray-600 align-top">
                  <div
                    className="max-w-64"
                    onMouseEnter={(e) => {
                      clearHideTimer()
                      const rect = (e.currentTarget as HTMLDivElement).getBoundingClientRect()
                      anchorRectRef.current = rect
                      setHoverText(r.content || '')
                      setHoverId(r.id)
                    }}
                    onMouseLeave={hideTooltipLater}
                  >
                    <span>{(r.content || '').slice(0, 10)}{(r.content || '').length > 10 ? '…' : ''}</span>
                  </div>
                </td>

                <td className="px-3 py-2 border-t">
                  <TagInput
                    value={r.tags || []}
                    onChange={(tags)=>{ updateTracked(r.id,{ tags }); setRows(prev => prev.map(x=> x.id===r.id? { ...x, tags }: x)); }}
                    suggestions={Array.from(new Set(getTracked().flatMap(x => x.tags || [])))}
                  />
                </td>

                <td className="px-3 py-2 border-t">
                  <input className="ui-input-sm" placeholder="https://..." value={r.permalink || ''}
                    onChange={e=>{ updateTracked(r.id,{ permalink: e.target.value }); setRows(prev=>prev) }} />
                </td>

                <td className="px-3 py-2 border-t">
                  <input className="ui-date-sm" type="date" value={r.publishDate || ''}
                    onChange={e=>{ updateTracked(r.id,{ publishDate: e.target.value }); setRows(prev => prev.map(x=> x.id===r.id? { ...x, publishDate: e.target.value }: x)); }} />
                </td>

                <td className="px-3 py-2 border-t ui-gap-x">
                  <input className="ui-input-xs" type="text" inputMode="numeric" value={r.likes ?? 0}
                    onChange={e=>{ const v = Number(e.target.value||0); updateTracked(r.id,{ likes: v }); setRows(prev => prev.map(x=> x.id===r.id? { ...x, likes: v }: x)); }} />
                </td>

                <td className="px-3 py-2 border-t ui-gap-x">
                  <input className="ui-input-xs" type="text" inputMode="numeric" value={r.comments ?? 0}
                    onChange={e=>{ const v = Number(e.target.value||0); updateTracked(r.id,{ comments: v }); setRows(prev => prev.map(x=> x.id===r.id? { ...x, comments: v }: x)); }} />
                </td>

                <td className="px-3 py-2 border-t ui-gap-x">
                  <input className="ui-input-xs" type="text" inputMode="numeric" value={r.shares ?? 0}
                    onChange={e=>{ const v = Number(e.target.value||0); updateTracked(r.id,{ shares: v }); setRows(prev => prev.map(x=> x.id===r.id? { ...x, shares: v }: x)); }} />
                </td>

                <td className="px-3 py-2 border-t ui-gap-x">
                  <input className="ui-input-xs" type="text" inputMode="numeric" value={r.saves ?? 0}
                    onChange={e=>{ const v = Number(e.target.value||0); updateTracked(r.id,{ saves: v }); setRows(prev => prev.map(x=> x.id===r.id? { ...x, saves: v }: x)); }} />
                </td>

                <td className="px-3 py-2 border-t">
                  <input className="ui-input-sm" value={r.notes || ''}
                    onChange={e=>{ const v = e.target.value; updateTracked(r.id,{ notes: v }); setRows(prev => prev.map(x=> x.id===r.id? { ...x, notes: v }: x)); }} />
                </td>

                <td className="px-3 py-2 border-t">{r.createdAt?.replace('T',' ').slice(0,19) || '-'}</td>

                <td className="px-3 py-2 border-t">
                  <div className="flex gap-2 justify-end">
                    <button className="btn btn-ghost text-xs" onClick={()=> { removeTracked(r.id); refresh() }}>移除</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {hoverId && hoverPos && (
        <div
          ref={tooltipRef}
          className="fixed z-50 w-[24rem] max-h-56 overflow-auto p-2 ui-tooltip ui-12 whitespace-pre-wrap"
          style={{ left: hoverPos.left, top: hoverPos.top }}
          onMouseEnter={clearHideTimer}
          onMouseLeave={hideTooltipLater}
        >
          {hoverText}
        </div>
      )}
    </div>
  )
}

function SearchBar({ onFilter }: { onFilter: (keyword: string, start?: string, end?: string) => void }){
  const [kw, setKw] = useState('')
  const [start, setStart] = useState('')
  const [end, setEnd] = useState('')

  return (
    <div className="card card-body flex flex-wrap items-end gap-3">
      <div>
        <label className="block text-sm text-gray-600">關鍵字</label>
        <input className="ui-input-sm" placeholder="輸入關鍵字" value={kw} onChange={e=>setKw(e.target.value)} />
      </div>
      <div>
        <label className="block text-sm text-gray-600">開始日期</label>
        <input className="ui-date-sm" type="date" value={start} onChange={e=>setStart(e.target.value)} />
      </div>
      <div>
        <label className="block text-sm text-gray-600">結束日期</label>
        <input className="ui-date-sm" type="date" value={end} onChange={e=>setEnd(e.target.value)} />
      </div>
      <div className="ml-auto flex gap-2">
        <button className="btn btn-outline" onClick={()=> onFilter(kw, start || undefined, end || undefined)}>搜尋</button>
        <button className="btn btn-ghost" onClick={()=> { setKw(''); setStart(''); setEnd(''); onFilter('', undefined, undefined) }}>重置</button>
      </div>
    </div>
  )
}

function TagInput({ value, onChange, suggestions }: { value: string[]; onChange: (v: string[]) => void; suggestions: string[] }){
  const [text, setText] = useState('')
  const exist = new Set(value)
  const filtered = suggestions.filter(s => s.toLowerCase().includes(text.toLowerCase()) && !exist.has(s)).slice(0, 6)

  const add = (tag: string) => {
    const t = tag.trim()
    if (!t) return
    if (exist.has(t)) { setText(''); return }
    onChange([...value, t]); setText('')
  }
  const remove = (tag: string) => onChange(value.filter(t => t !== tag))

  return (
    <div className="min-w-56">
      <div className="flex flex-wrap gap-1 mb-1">
        {value.map(t => (
          <span key={t} className="ui-chip">
            #{t}
            <button className="ui-close" onClick={()=>remove(t)}>×</button>
          </span>
        ))}
      </div>
      <div className="relative">
        <input className="ui-input-sm" placeholder="輸入後按 Enter 或選擇建議" value={text}
          onChange={e=>setText(e.target.value)}
          onKeyDown={e=>{ if (e.key==='Enter') { e.preventDefault(); add(text) } }} />
        {text && filtered.length>0 && (
          <div className="absolute z-20 mt-1 w-full ui-tooltip ui-12 max-h-40 overflow-auto">
            {filtered.map(s => (
              <div key={s} className="px-2 py-1 hover:bg-gray-100 cursor-pointer" onClick={()=>add(s)}>#{s}</div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

